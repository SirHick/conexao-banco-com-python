import mysql.connector
from config import DB_CONFIG

def total_produtos():
    conexao = None
    try:
        conexao = mysql.connector.connect(**DB_CONFIG)
        cursor = conexao.cursor()
        cursor.execute(
            "SELECT COUNT(*) AS total_produtos from produtos"
        )
        resultado = cursor.fetchone()
        print(resultado)
    except Exception as erro:
        print(f"Erro: {erro}")
    finally:
        if conexao and conexao.is_connected():
            conexao.close()


def valor_total_estoque():
    conexao = None
    try:
        conexao = mysql.connector.connect(**DB_CONFIG)
        cursor = conexao.cursor()
        cursor.execute(
            "SELECT SUM(preco) as valor_total_estoque from produtos"
        )
        resultado = cursor.fetchone()
        print(resultado)
    except Exception as erro:
        print(f"Erro: {erro}")
    finally:
        if conexao and conexao.is_connected():
            conexao.close()

def produto_mais_caro():
    conexao = None
    try:
        conexao = mysql.connector.connect(**DB_CONFIG)
        cursor = conexao.cursor()
        cursor.execute(
            "SELECT nome, preco FROM produtos WHERE preco = (SELECT MAX(preco) FROM produtos)"
        )
        resultado = cursor.fetchone()
        print(resultado)
    except Exception as erro:
        print(f"Erro: {erro}")
    finally:
        if conexao and conexao.is_connected():
            conexao.close()