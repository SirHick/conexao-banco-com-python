from flask import Flask, render_template

#Cria a aplicação Flask
app = Flask(__name__, template_folder="meus_templates")

#Define uma rota
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/prod")
def produtos():
    lista = [
        {"nome": "Arroz", "preco": 10.00, "categoria": "Alimento"},
        {"nome": "Feijão", "preco": 8.00, "categoria": "Alimento"},
        {"nome": "Ovo", "preco": 20.00, "categoria": "Alimento"},
        {"nome": "Farinha de trigo", "preco": 6.50, "categoria": "Alimento"},
        {"nome": "Bolo de Chcolate", "preco": 10.00, "categoria": "Alimento"}
    ]
    return render_template("produtos.html", produtos = lista)

@app.route("/sobre")
def sobre():
    return render_template("sobre.html")

#Inicia o servidor
if __name__ == "__main__":
    app.run(debug=True)