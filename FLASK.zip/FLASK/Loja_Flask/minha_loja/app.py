from flask import Flask

#Cria a aplicação Flask
app = Flask(__name__)

#Define uma rota
@app.route("/")
def index():
    return "Olá, boas vindas ao sistema."

@app.route("/produto")
def produto():
    return "Lista de Produtos: \n1 - Mouse\n2 - Teclado\n3 - Monitor"

@app.route("/produto/<int:id>")
def exibir_produto(id):
    return f"Exibindo produto com id {id}"

@app.route("/sobre")
def sobre():
    return "Sistema tudo ok"

#Inicia o servidor
if __name__ == "__main__":
    app.run(debug=True)