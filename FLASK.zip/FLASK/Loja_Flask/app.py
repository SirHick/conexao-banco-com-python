from flask import Flask, render_template

#Cria a aplicação Flask
app = Flask(__name__)

#Define uma rota
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/sobre")
def sobre():
    return render_template("sobre.html")

@app.route("/prod")
def produtos():
    lista = [
        {"nome": "Notebook", "preco": 3499.99, "categoria": "Eletrônico"},
        {"nome": "Monitor", "preco": 999.99, "categoria": "Eletrônico"},
        {"nome": "Mouse", "preco": 499.99, "categoria": "Eletrônico"}
    ]
    return render_template("produtos.html", produtos = lista)

#@app.route("/categoria/<nome>")
#def categoria(nome):
#    return f"Produtos da categoria: {nome}"

#Inicia o servidor
if __name__ == "__main__":
    app.run(debug=True)